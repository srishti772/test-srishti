#!/bin/bash
set -e

# Install Unzip
echo "Installing unzip..."
sudo apt update
sudo apt install -y unzip

# Install Node.js
echo "Installing Node.js..."
curl -sL https://deb.nodesource.com/setup_20.x -o /tmp/nodesource_setup.sh
sudo bash /tmp/nodesource_setup.sh
sudo apt install -y nodejs
node -v

# Install MySQL
echo "Installing MySQL server..."
sudo apt install -y mysql-server
sudo systemctl start mysql.service
echo "MySQL service status:"
systemctl status mysql.service

# Set Up MySQL Databases and Create Additional User
echo "Configuring MySQL databases and creating additional user..."
sudo mysql <<EOF
CREATE USER 'srishti772'@'localhost' IDENTIFIED BY 'testPassword!';
GRANT ALL PRIVILEGES ON *.* TO 'srishti772'@'localhost' WITH GRANT OPTION;
CREATE DATABASE test_db;
CREATE DATABASE prod_db;

-- Set root authentication method to mysql_native_password
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'testPassword!';
FLUSH PRIVILEGES;
EOF

echo "Databases and user configured successfully."
echo "Setup completed successfully."
